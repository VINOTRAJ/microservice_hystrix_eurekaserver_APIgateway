package optionalInLambda;

import java.util.Optional;

public class demo {

	public static void main(String[] args) {
	
		Integer num1=null;
		Integer num2=567;
		
		//we use optional to avoid nullpointerException,its shows only boolean type output.
		Optional<Integer> obj=Optional.ofNullable(num1);
		
		//we use .isEmpty() method.so if obj is null,it shows true else false
System.out.println(obj.isEmpty()+"   (.isEmpty() method.......) num1 has null,so it shows as true ->num1 is empty");

//we use .isPresent() method.so if data is available in obj,it shows true else false
		System.out.println(obj.isPresent()+"      (.isPresent() method.......)num1 has null,so it shows as false->num1 is empty");

		
		
		
		
		Optional<Integer> obj2=Optional.ofNullable(num2);
System.out.println(obj2.isPresent());
	}

}
