package lambdaExpressionStreamApiProject1;


import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class Demo1 {

	public static void main(String[] args) {
		
		System.out.println("---------Collect as Terminal operation------------");
		//create a list of integer
List<Integer> list=Arrays.asList(1,2,3,4,5);
         //demonstrate map method
List<Integer> squareOfNum=list.stream().map(x->x*x).collect(Collectors.toList());
System.out.println(squareOfNum);
		

List<Integer> list1=Arrays.asList(8,3,6,1,0,4,3);
//demonstrate sorted method.
List<Integer> sortedData=list1.stream().sorted().collect(Collectors.toList());
System.out.println(sortedData);

List<String> list2=Arrays.asList("vinoth","Rajendran","kandasamy");
//demonstrate filter method
List<String> filteredData=list2.stream().filter(x->x.startsWith("R")).collect(Collectors.toList());
System.out.println(filteredData);


System.out.println("---------ForEach as Terminal operation------------");

List<Integer> list3=Arrays.asList(1,2,3,4,5);

list3.stream().map(x->x).forEach(y->System.out.println(y));



List<String> list4=Arrays.asList("vinoth","Rajendran","kandasamy");
list4.stream().sorted().forEach(x->System.out.println(x));



List<String> list5=Arrays.asList("chennai","coimbatore","salem");	
list5.stream().filter(x->x.startsWith("s")).forEach(y->System.out.println(y));

	

	
	
	
	
	}


}
